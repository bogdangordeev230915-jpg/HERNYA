# HERNYA Messenger

A starter messenger with brown/white UI, registration, unique user codes, login, user search, direct text messages, voice recording, and file uploads up to 100 MB.

## Deploy to Render
1. Create a GitHub repository named `HERNYA`.
2. Upload these project files to the repository root (keep `server.js`, `package.json`, `render.yaml`, `public/`).
3. In Render choose **New → Blueprint**, connect the GitHub repository, and apply the `render.yaml` blueprint.
4. Wait for the web service and PostgreSQL database to finish provisioning. Open the web service URL.
5. In Render service settings, confirm `JWT_SECRET` exists. Do not share it publicly.

## Important storage limitation
This starter stores uploads in the service's local `uploads/` directory. Render web-service filesystems are ephemeral, so uploaded files can disappear after a redeploy/restart. Before using this with real users, move file storage to persistent object storage (for example, an S3-compatible service) and add rate limiting, abuse protection, backups, and privacy controls. PostgreSQL stores account and message metadata persistently.

## Local run
Requires Node.js 20+ and PostgreSQL. Copy `.env.example` to `.env`, set `DATABASE_URL` and a long random `JWT_SECRET`, then run:
```sh
npm install
npm start
```
Open `http://localhost:3000`.

## Security notes
- Passwords are hashed with bcrypt.
- User codes are random and unique.
- HTTPS is provided by Render.
- This is a starter project, not a fully audited production messenger. It does not provide end-to-end encryption or realtime WebSocket delivery; the UI refreshes messages periodically.
