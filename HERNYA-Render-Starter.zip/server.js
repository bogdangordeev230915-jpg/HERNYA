const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { Pool } = require('pg');

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost')
    ? { rejectUnauthorized: false } : false
});
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) console.warn('WARNING: JWT_SECRET is missing. Set it in your environment.');

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      code TEXT UNIQUE NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      middle_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      recipient_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT,
      attachment_url TEXT,
      attachment_name TEXT,
      attachment_type TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS messages_pair_idx ON messages(sender_id, recipient_id, created_at);
  `);
}
function makeCode() {
  return 'H-' + crypto.randomBytes(7).toString('hex').toUpperCase();
}
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  try {
    if (!token) throw new Error('missing');
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Войдите в аккаунт заново.' });
  }
}

const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).slice(0, 12))
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024, files: 1 }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'HERNYA' }));

app.post('/api/register', async (req, res) => {
  try {
    const { firstName, lastName, middleName, password } = req.body || {};
    if (![firstName, lastName, middleName, password].every(v => typeof v === 'string' && v.trim())) {
      return res.status(400).json({ error: 'Заполните все четыре поля.' });
    }
    if (password.length < 8) return res.status(400).json({ error: 'Пароль должен содержать минимум 8 символов.' });
    if (password.length > 200) return res.status(400).json({ error: 'Слишком длинный пароль.' });
    const hash = await bcrypt.hash(password, 12);
    let result;
    for (let i = 0; i < 5; i++) {
      try {
        result = await pool.query(
          'INSERT INTO users(code, first_name, last_name, middle_name, password_hash) VALUES($1,$2,$3,$4,$5) RETURNING id, code, first_name, last_name, middle_name',
          [makeCode(), firstName.trim().slice(0,80), lastName.trim().slice(0,80), middleName.trim().slice(0,80), hash]
        );
        break;
      } catch (e) { if (e.code !== '23505' || i === 4) throw e; }
    }
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Не удалось создать аккаунт.' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { code, password } = req.body || {};
    const q = await pool.query('SELECT * FROM users WHERE code = $1', [String(code || '').trim()]);
    if (!q.rowCount || !await bcrypt.compare(String(password || ''), q.rows[0].password_hash)) {
      return res.status(401).json({ error: 'Неверный код или пароль.' });
    }
    const u = q.rows[0];
    res.json({
      token: jwt.sign({ id: u.id }, JWT_SECRET, { expiresIn: '7d' }),
      user: { id: u.id, code: u.code, first_name: u.first_name, last_name: u.last_name, middle_name: u.middle_name }
    });
  } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка входа.' }); }
});

app.get('/api/me', auth, async (req, res) => {
  const q = await pool.query('SELECT id, code, first_name, last_name, middle_name FROM users WHERE id=$1', [req.user.id]);
  if (!q.rowCount) return res.status(404).json({ error: 'Пользователь не найден.' });
  res.json(q.rows[0]);
});

app.get('/api/search/:code', auth, async (req, res) => {
  const q = await pool.query(
    'SELECT id, code, first_name, last_name, middle_name FROM users WHERE code=$1',
    [req.params.code.trim()]
  );
  if (!q.rowCount) return res.status(404).json({ error: 'Пользователь с таким кодом не найден.' });
  if (String(q.rows[0].id) === String(req.user.id)) return res.status(400).json({ error: 'Это ваш собственный код.' });
  res.json(q.rows[0]);
});

app.get('/api/contacts', auth, async (req, res) => {
  const q = await pool.query(`
    SELECT DISTINCT ON (other_id) other_id AS id, code, first_name, last_name, middle_name, body, created_at
    FROM (
      SELECT CASE WHEN sender_id=$1 THEN recipient_id ELSE sender_id END AS other_id,
        CASE WHEN sender_id=$1 THEN recipient_id ELSE sender_id END AS uid,
        body, created_at
      FROM messages WHERE sender_id=$1 OR recipient_id=$1
    ) m JOIN users u ON u.id=m.uid
    ORDER BY other_id, created_at DESC`, [req.user.id]);
  res.json(q.rows);
});

app.get('/api/messages/:userId', auth, async (req, res) => {
  const otherId = Number(req.params.userId);
  if (!Number.isSafeInteger(otherId) || otherId < 1) return res.status(400).json({ error: 'Неверный пользователь.' });
  const q = await pool.query(`
    SELECT id, sender_id, recipient_id, body, attachment_url, attachment_name, attachment_type, created_at
    FROM messages
    WHERE (sender_id=$1 AND recipient_id=$2) OR (sender_id=$2 AND recipient_id=$1)
    ORDER BY created_at ASC LIMIT 500`, [req.user.id, otherId]);
  res.json(q.rows);
});

app.post('/api/messages/:userId', auth, async (req, res) => {
  const otherId = Number(req.params.userId);
  const body = typeof req.body?.body === 'string' ? req.body.body.trim() : '';
  if (!Number.isSafeInteger(otherId) || otherId < 1 || !body || body.length > 10000) {
    return res.status(400).json({ error: 'Сообщение пустое или слишком длинное.' });
  }
  if (String(otherId) === String(req.user.id)) return res.status(400).json({ error: 'Нельзя писать самому себе.' });
  const target = await pool.query('SELECT id FROM users WHERE id=$1', [otherId]);
  if (!target.rowCount) return res.status(404).json({ error: 'Получатель не найден.' });
  const q = await pool.query(
    'INSERT INTO messages(sender_id,recipient_id,body) VALUES($1,$2,$3) RETURNING *',
    [req.user.id, otherId, body]
  );
  res.status(201).json(q.rows[0]);
});

app.post('/api/messages/:userId/file', auth, (req, res) => {
  upload.single('file')(req, res, async err => {
    if (err) {
      const tooLarge = err.code === 'LIMIT_FILE_SIZE';
      return res.status(tooLarge ? 413 : 400).json({ error: tooLarge ? 'Максимальный размер файла — 100 МБ.' : 'Не удалось загрузить файл.' });
    }
    try {
      const otherId = Number(req.params.userId);
      if (!Number.isSafeInteger(otherId) || otherId < 1 || otherId === Number(req.user.id)) {
        if (req.file) fs.unlink(req.file.path, () => {});
        return res.status(400).json({ error: 'Неверный получатель.' });
      }
      const target = await pool.query('SELECT id FROM users WHERE id=$1', [otherId]);
      if (!target.rowCount) {
        if (req.file) fs.unlink(req.file.path, () => {});
        return res.status(404).json({ error: 'Получатель не найден.' });
      }
      if (!req.file) return res.status(400).json({ error: 'Выберите файл.' });
      const url = '/uploads/' + path.basename(req.file.filename);
      const q = await pool.query(
        'INSERT INTO messages(sender_id,recipient_id,attachment_url,attachment_name,attachment_type) VALUES($1,$2,$3,$4,$5) RETURNING *',
        [req.user.id, otherId, url, req.file.originalname.slice(0,255), req.file.mimetype.slice(0,120)]
      );
      res.status(201).json(q.rows[0]);
    } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сохранения файла.' }); }
  });
});

app.use('/uploads', express.static(uploadDir, { fallthrough: false, maxAge: '1h' }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const port = process.env.PORT || 3000;
initDb().then(() => app.listen(port, '0.0.0.0', () => console.log(`HERNYA listening on ${port}`)))
  .catch(err => { console.error('Database initialization failed:', err); process.exit(1); });
